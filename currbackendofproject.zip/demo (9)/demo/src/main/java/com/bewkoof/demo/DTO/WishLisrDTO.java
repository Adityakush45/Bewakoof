package com.bewkoof.demo.DTO;

public record WishLisrDTO(int id,int prodId) {


}
